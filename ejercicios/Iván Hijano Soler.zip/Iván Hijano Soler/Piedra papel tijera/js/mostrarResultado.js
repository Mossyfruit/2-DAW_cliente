'use strict'

function mostrarResultado(playerScore,computerScore){
    document.getElementById("player-score").innerHTML = playerScore;
    document.getElementById("computer-score").innerHTML = computerScore;
}