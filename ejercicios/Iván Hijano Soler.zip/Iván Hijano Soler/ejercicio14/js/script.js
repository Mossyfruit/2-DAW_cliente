'use strict'
//funcion para crear caracteres aleatorios en una matriz
let partido;
let charLength=10;
let times=0;
document.getElementById("generar").onclick= function(){
    getLength();
    createRandomChar(charLength);
}




