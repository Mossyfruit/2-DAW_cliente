'use strict'
 
function getLength(){
    times=parseInt(document.getElementById("texto").value);
    console.log(times);

    return times;

}